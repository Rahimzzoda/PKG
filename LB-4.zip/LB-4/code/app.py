from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Алгоритмы растеризации
def step_by_step_line(x1, y1, x2, y2):
    points = []
    dx = x2 - x1
    dy = y2 - y1
    steps = max(abs(dx), abs(dy))
    x_increment = dx / steps
    y_increment = dy / steps
    x, y = x1, y1
    for _ in range(steps + 1):
        points.append((round(x), round(y)))
        x += x_increment
        y += y_increment
    return points

def dda_line(x1, y1, x2, y2):
    points = []
    dx = x2 - x1
    dy = y2 - y1
    steps = max(abs(dx), abs(dy))
    x_increment = dx / steps
    y_increment = dy / steps
    x, y = x1, y1
    for _ in range(steps):
        points.append((round(x), round(y)))
        x += x_increment
        y += y_increment
    return points

def bresenham_line(x1, y1, x2, y2):
    points = []
    dx = abs(x2 - x1)
    dy = abs(y2 - y1)
    sx = 1 if x1 < x2 else -1
    sy = 1 if y1 < y2 else -1
    err = dx - dy
    while True:
        points.append((x1, y1))
        if x1 == x2 and y1 == y2:
            break
        e2 = err * 2
        if e2 > -dy:
            err -= dy
            x1 += sx
        if e2 < dx:
            err += dx
            y1 += sy
    return points

def bresenham_circle(xc, yc, r):
    points = []
    x = 0
    y = r
    d = 3 - 2 * r
    while y >= x:
        points.extend([(xc + x, yc + y), (xc - x, yc + y), 
                       (xc + x, yc - y), (xc - x, yc - y),
                       (xc + y, yc + x), (xc - y, yc + x), 
                       (xc + y, yc - x), (xc - y, yc - x)])
        x += 1
        if d > 0:
            y -= 1
            d += 4 * (x - y) + 10
        else:
            d += 4 * x + 6
    return points

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/draw', methods=['POST'])
def draw():
    data = request.get_json()
    algorithm = data['algorithm']
    params = data['params']
    
    if algorithm == 'step_by_step':
        points = step_by_step_line(*params)
    elif algorithm == 'dda':
        points = dda_line(*params)
    elif algorithm == 'bresenham':
        points = bresenham_line(*params)
    elif algorithm == 'circle':
        points = bresenham_circle(*params)
    else:
        return jsonify({'error': 'Unknown algorithm'}), 400

    return jsonify({'points': points})

if __name__ == '__main__':
    app.run(debug=True)
